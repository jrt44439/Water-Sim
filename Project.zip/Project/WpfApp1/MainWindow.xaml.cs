﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Reflection;


namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string temperatureSurface = null;
        double solidsurfaceSize= 0;
        double solidsurfaceTemp= 0;
        double semisurfaceSize = 0;
        double semisurfaceTemp = 0;
        double poroussurfaceSize = 0;
        double poroussurfaceTemp = 0;


        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(Page_Loaded);
            this.Loaded += new RoutedEventHandler(Page2_Loaded);



        }

        void Page2_Loaded(object sender, RoutedEventArgs e)
        {
            SurfaceInputs initial2 = new SurfaceInputs();
            {
                initial2.TSinput = "0";
                initial2.SSinput = "0";
                initial2.MSinput = "default";

            };

            this.Surface.DataContext = initial2;
        }

        void Page_Loaded(object sender, RoutedEventArgs e)
        {
            MapInputs initial = new MapInputs();
            {
                initial.Tinput = "0";
                initial.Vrinput = "0";
                initial.Lrinput = "0";
                initial.Ainput = "0";
            };
            this.Inputs.DataContext = initial;

            
        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9.-]+");
            e.Handled = regex.IsMatch(e.Text);
        }


        public void StartSimButton_Click(object sender, RoutedEventArgs e)
        {

            double rainTemp = double.Parse(tempInput.Text);
            double rainVolume = double.Parse(volumeInput.Text);
            double rainTime = double.Parse(timeInput.Text);
            double areaSize = double.Parse(sizeInput.Text);

            double solidrunoffCo = 0.98;
            double semirunoffCo = 0.7;
            double porousrunoffCo = 0.35;           
            double solidrunoffSubtotal =0;
            double semirunoffSubtotal = 0;
            double porousrunoffSubtotal = 0;
            double runoffSubtotal;
            double runoffTotal;
            double absorbSubtotal;
            double absorbMinute;
            double semiabsorbSubtotal = 0;
            double porousabsorbSubtotal = 0;
            double evaporation;
            double evaporationMinute;

            

            solidrunoffSubtotal = ((solidrunoffCo * (rainVolume / (rainTime / 60)) * solidsurfaceSize) / 96.23);
            semirunoffSubtotal = ((semirunoffCo * (rainVolume / (rainTime / 60)) * semisurfaceSize) / 96.23);
            porousrunoffSubtotal = ((porousrunoffCo * (rainVolume / (rainTime / 60)) * poroussurfaceSize) / 96.23);
            runoffSubtotal = solidrunoffSubtotal + semirunoffSubtotal + porousrunoffSubtotal;
            double graphHeight = runoffSubtotal * 3;
            runoffTotal = (runoffSubtotal * rainTime);
            runoffSubtotal = Math.Round(runoffSubtotal, 2);
            runoffOutput.Text = runoffTotal.ToString("N3");

            semiabsorbSubtotal = ((((144 * semisurfaceSize) * 0.5) * (rainTime / 60))/231);
            porousabsorbSubtotal =((((144 * poroussurfaceSize) * 3.94) * (rainTime / 60))/231);
            absorbSubtotal = semiabsorbSubtotal + porousabsorbSubtotal;
            absorbMinute = (absorbSubtotal / rainTime);
            absorbMinute = Math.Round(absorbMinute, 2);
            absorbOutput.Text = absorbSubtotal.ToString("N3");

            double totalRainfall = (((rainVolume * areaSize) * 144) / 231);
            evaporation = (totalRainfall - runoffTotal - absorbSubtotal);
            evaporationMinute = (evaporation / 60);
            evaporationMinute = Math.Round(evaporationMinute, 2);
            evapOutput.Text = evaporation.ToString("N3");



            List<Bar> _bar = new List<Bar>();
            _bar.Add(new Bar() { BarName = "RunOff", Value = runoffSubtotal });
            _bar.Add(new Bar() { BarName = "Absorbtion", Value = absorbMinute });
            _bar.Add(new Bar() { BarName = "Evaporation", Value = evaporationMinute });

            this.DataContext = new RecordCollection(_bar);


        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {

        }

        public void AddSurfaceButton_Click(object sender, RoutedEventArgs e)
        {

            if (Cbi1.IsSelected)
            {
                RedCircle.Visibility = Visibility.Visible;
                solidsurfaceTemp = double.Parse(tempSurface.Text);
                solidsurfaceSize = double.Parse(sizeSurface.Text);
                surfaceInfo1.Text = materialSurface.Text +"\r\n" + tempSurface.Text + "\r\n" + sizeSurface.Text;
                materialSurface.Text = "0";
                tempSurface.Text = "0";
                sizeSurface.Text = "0";

            }

            if (Cbi2.IsSelected)
            {
             
                GreenCircle.Visibility = Visibility.Visible;
                semisurfaceTemp = double.Parse(tempSurface.Text);
                semisurfaceSize = double.Parse(sizeSurface.Text);
                surfaceInfo2.Text = materialSurface.Text + "\r\n" + tempSurface.Text + "\r\n" + sizeSurface.Text;
                materialSurface.Text = "0";
                tempSurface.Text = "0";
                sizeSurface.Text = "0";
            }

            if (Cbi3.IsSelected)
            {

                BlueCricle.Visibility = Visibility.Visible;
                poroussurfaceTemp = double.Parse(tempSurface.Text);
                poroussurfaceSize = double.Parse(sizeSurface.Text);
                surfaceInfo3.Text = materialSurface.Text + "\r\n" + tempSurface.Text + "\r\n" + sizeSurface.Text;
                materialSurface.Text = "0";
                tempSurface.Text = "0";
                sizeSurface.Text = "0";
            }
        }



        private void ExportAsPdfButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void SaveSimulationButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void PlayButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void PauseButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void FastForwardButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void RewindButton_Click(object sender, RoutedEventArgs e)
        {

        }

        public class MapInputs
        {
            public string Tinput { get; set; }
            public string Vrinput { get; set; }
            public string Lrinput { get; set; }
            public string Ainput { get; set; }
        }

        public class SurfaceInputs
        {
            public string TSinput { get; set; }
            public string SSinput { get; set; }
            public string MSinput { get; set; }
        }


        private void TypeSurface_FocusableChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (typeSurface.SelectedIndex == 0)
            {
                addSurface.IsEnabled = false;
            }
        }
    }

    // Got following code from: http://dotnetvisio.blogspot.sg/2013/08/wpf-create-custom-bar-chart-using-grid.html
    class RecordCollection : ObservableCollection<Record>
    {

        public RecordCollection(List<Bar> barvalues)
        {
            Random rand = new Random();
            BrushCollection brushcoll = new BrushCollection();

            foreach (Bar barval in barvalues)
            {
                int num = rand.Next(brushcoll.Count / 3);
                Add(new Record(barval.Value, brushcoll[num], barval.BarName));
            }
        }

    }

    class BrushCollection : ObservableCollection<Brush>
    {
        public BrushCollection()
        {
            Type _brush = typeof(Brushes);
            PropertyInfo[] props = _brush.GetProperties();
            foreach (PropertyInfo prop in props)
            {
                Brush _color = (Brush)prop.GetValue(null, null);
                if (_color != Brushes.LightSteelBlue && _color != Brushes.White &&
                     _color != Brushes.WhiteSmoke && _color != Brushes.LightCyan &&
                     _color != Brushes.LightYellow && _color != Brushes.Linen)
                    Add(_color);
            }
        }
    }

    class Bar
    {

        public string BarName { set; get; }

        public double Value { set; get; }

    }

    class Record : INotifyPropertyChanged
    {
        public Brush Color { set; get; }

        public string Name { set; get; }

        private double _data;
        public  double Data
        {
            set
            {
                if (_data != value)
                {
                    _data = value;

                }
            }
            get
            {
                return _data;
            }
        }

        private double _Hdata;
        public double HData
        {
            set
            {
                if (_Hdata != value)
                {
                    _Hdata = (value+value+value);

                }
            }
            get
            {
                return _Hdata;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public Record(double value, Brush color, string name)
        {
            Data = value;
            HData = value;
            Color = color;
            Name = name;
        }

        protected void PropertyOnChange(string propname)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propname));
            }
        }
    }
    [ValueConversion(typeof(object), typeof(bool))]
    public class NullToBoolConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value == null) return false;
            PropertyInfo propertyInfo = value.GetType().GetProperty("Count");
            if (propertyInfo != null)
            {
                int count = (int)propertyInfo.GetValue(value, null);
                return count > 0;
            }
            if (!(value is bool || value is bool?)) return true;
            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return value;
        }
    }
}
